import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import java.util.Scanner;


public class Main {

	
	static File fichero = new File("matriz1.txt");
	static int[][] matriz;
	static Random r = new Random();

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);  
        int filas;
        int columnas;
        System.out.print("Introduzca el número de filas y columnas de la matriz cuadrada: ");
        filas = sc.nextInt();  
       // System.out.print("Introduzca el número de columnas de la matriz: ");
        //columnas = sc.nextInt(); 
        matriz=generarMatrizAleatoria(filas, filas);
        
        Runtime runtime = Runtime.getRuntime();        
		System.out.println("Numero de cores: " + runtime.availableProcessors());

		int numCores = runtime.availableProcessors();
		
        //-----------------------------------------------------parte para generar los hilos-------------------------------------------
        
		int rango = Math.round(filas / (float)numCores);
		
		if (numCores > filas)
		{
			numCores=filas-1;
		}
		
		
        //NUM ES UN MILLÓN
		//System.out.println(" El rango es " + rango); //en mi caso son 250000, porque tengo 4 cores
		int inicioRango = 0;
		int finRango = rango;
		mostrarMatriz();
		Hilo[] hilos = new Hilo[numCores];

		// Lanzamos tantos hilos como cores tenga el sistema 999983
		for (int i = 0; i < numCores; i++)
		{
			//new Thread(new Hilo(matriz, inicioRango, finRango)).start();
			//System.out.println("Estamos en el hilo " +i + " inicio de rango " + inicioRango + " fin de rango "+ finRango);
			hilos[i]= new Hilo(matriz,inicioRango,finRango);
			hilos[i].start();
			inicioRango += rango;
			finRango += rango;
			if(i == numCores - 2)//para asegurarnos que el hilo ultimo termina
			{
				finRango = filas;				
			}
		}
		
		for (int j=0;j<numCores;j++)
		{
			try {hilos[j].join();} catch (InterruptedException e) {}
		}
	
		int []valores=new int[3];
		int []sumavalores=new int[3];
		

			for (int k=0;k<hilos.length;k++)
			{
				//valores guarda el número total de rojos, verdes y azules
				valores[0]+=hilos[k].getNumColores()[0];
				sumavalores[0]+=hilos[k].getSumaRojos();
				valores[1]+=hilos[k].getNumColores()[1];
				sumavalores[1]+=hilos[k].getSumaVerdes();
				valores[2]+=hilos[k].getNumColores()[2];
				sumavalores[2]+=hilos[k].getSumaAzules();
			}

			
		
		
		//averiguamos la tonalidad según las intensidades de color
		
		int color= getMayor(sumavalores[0], sumavalores[1],sumavalores[2]);
		
		String []tono={"rojizo","verdoso","azulado"};
		System.out.println("La suma total de los colores rojos es "+ sumavalores[0] + " de los verdes es "+ sumavalores[1] + " y de los azules es "+sumavalores[2]);
		System.out.println("El tono general de la imágen es de color "+tono[color]);
		double sumatotal=valores[0]+valores[1]+valores[2];
		
		System.out.println("El numero total de rojos es "+ valores[0]+ " y su % es "+ Math.round((valores[0]/sumatotal)*100));
		System.out.println("El numero total de verdes es "+ valores[1]+ " y su % es "+ Math.round((valores[1]/sumatotal)*100));
		System.out.println("El numero total de azules es "+ valores[2]+ " y su % es "+ Math.round((valores[2]/sumatotal)*100));
	
		
        //----------------------------------------------------------------------------------------------------------------------------

        
	}
	
	private static int getMayor(int i, int j, int k) {
		 if (i>j && i>k)
	           return 0;
		   if (j>i && j>k)
			   return 1;
		   if (k>i && k>j)
	        	return 2;
		   return i;
	}

	private static int[][] generarMatrizAleatoria(int filas, int columnas) {
		// TODO Auto-generated method stub
		BufferedWriter bw = null;
	    FileWriter fw = null;
	    matriz = new int[filas][columnas];

	    try{
	    	 if (!fichero.exists()) {
	    		 fichero.createNewFile();
	         }

	    	 fw = new FileWriter(fichero.getAbsoluteFile(), true);
	         bw = new BufferedWriter(fw);
	         //creo la matríz con números aleatorios del 0 al 2
	         for (int i=0;i<filas;i++)
	         {
	        	 for(int j=0;j<columnas;j++)
	        	 {
	        		 Integer valor=r.nextInt(255)+1;
	        		 matriz[i][j]=valor;
	        		 bw.write(valor.toString());
	        		 bw.write(" ");
	        	 }
	        	 bw.write("\n");
	         }
	         bw.write("\n");
	         if (bw != null)
		         bw.close();
		     if (fw != null)
		         fw.close();
	   	}
	    catch(IOException ex)
	   	{
	   		ex.printStackTrace();
	   	}

	  return matriz;
	}

	private static void mostrarMatriz()
	{
		for (int i=0;i<matriz.length;i++)
        {
       	 for(int j=0;j<matriz[i].length;j++)
       	 {
       		 System.out.print(" " + matriz[i][j] + " ");
       	 }
       	 System.out.println();
        }
	}

}