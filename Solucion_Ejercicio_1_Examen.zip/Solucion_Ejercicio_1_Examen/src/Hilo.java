
public class Hilo extends Thread {
	
	
	 private static int [][]matriz;
	 private int filasiniciorango, filasfinalrango,numRojo,numVerde,numAzul;
	 private int[] colorPrincipal;


	public Hilo(int [][]m, int filasinicio, int filasfinal)
	{
		matriz=m;
		this.filasiniciorango=filasinicio;
		this.filasfinalrango=filasfinal;
		numRojo=0;//estas variables representan la suma de rojo verde y azul por cada hilo, para sacar la tonalidad general
		numVerde=0;
		numAzul=0;
		this.colorPrincipal = new int[3];//me quedo el número de rojos, verdes o azules
	}

	public int getSumaRojos(){return numRojo;}
	public int getSumaVerdes(){return numVerde;}
	public int getSumaAzules(){return numAzul;}
	public int[] getNumColores(){return this.colorPrincipal;}


	@Override
	public void run()
	{

		for (int i=this.filasiniciorango;i<this.filasfinalrango;i++)
		{
			for (int j=0;j<matriz[i].length-2;j+=3)
			{				
				//me quedo con el color más fuerte del pixel e incremento el array en el color correspondiente
				
				int mayor = getMayor(matriz[i][j],matriz[i][j+1], matriz[i][j+2]);			
				this.colorPrincipal[mayor]++;
				numRojo+=matriz[i][j];
				numVerde+=matriz[i][j+1];
				numAzul+=matriz[i][j+2];				
			}
		}

	}

	private int getMayor(int i, int j, int k) 
	{
		   if (i>j && i>k)
	           return 0;
		   if (j>i && j>k)
			   return 1;
		   if (k>i && k>j)
	        	return 2;
		   return i;
	}
}