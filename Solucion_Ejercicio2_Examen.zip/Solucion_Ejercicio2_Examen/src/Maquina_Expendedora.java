
public class Maquina_Expendedora {
	
int  cocacolas;

	
	public Maquina_Expendedora(int c){	
	
		this.cocacolas=c;
		
	}
	
	public synchronized void compro(int numerobebidas)
	{
	
			while  (numerobebidas > this.cocacolas)
			{//si no hay cocacolas suficientes me voy a dormir hasta que haya
				try {		
					notify();
					wait();
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("soy el comprador de Coca-Colas y ahoramismo hay: "+ this.cocacolas + " Coca-Colas, y voy a comprar: "+ numerobebidas);
			this.cocacolas = this.cocacolas - numerobebidas;
			System.out.println("Ahora quedan " + this.cocacolas + " Coca-Colas");
			notify();//por si el reponedor está esperando	
	}
	
	public synchronized boolean repongo()
	{		
		if  (cocacolas>3)
		{	
			try {
				notify();
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return false;
		}
		//en caso de que alguna de ellas este a 0 se añaden las tres hasta 10
		System.out.println("soy el reponedor y entro a reponer ");	
		this.cocacolas=10;
		notify();		
		return true;
	}


}
