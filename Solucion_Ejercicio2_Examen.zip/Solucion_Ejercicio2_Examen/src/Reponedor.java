
public class Reponedor extends Thread {
	
private Maquina_Expendedora me;

	
	public Reponedor(Maquina_Expendedora me){
		
		this.me=me;
	
	}
	
	public void run()
	{
		while(true)
		{
			me.repongo();
		}
	}

}
