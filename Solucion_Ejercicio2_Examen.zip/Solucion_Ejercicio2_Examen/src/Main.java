
public class Main {

	public static void main(String[] args) {
		
		Maquina_Expendedora me = new Maquina_Expendedora(10); //diez cocacolas
		
		Comprador hc = new Comprador(me);		
		Reponedor rp=new Reponedor(me);
		hc.start();
		rp.start();
		
	}

}
