import java.util.Random;

public class Comprador extends Thread{
	
	private Maquina_Expendedora me;
	private String tipo_comprador;
	
	public Comprador(Maquina_Expendedora me){
		
		this.me=me;
	
	}
	
	public void run()
	{
		Random r = new Random();
		while(true)
		{
			me.compro(r.nextInt(3)+1);
		}
	}
	


}
