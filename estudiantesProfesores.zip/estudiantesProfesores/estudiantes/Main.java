package estudiantes;

public class Main {

	public static void main(String[] args) {
		
		Biblioteca bb = new Biblioteca();
		
		Estudiante []es = new Estudiante[10];
		Profesor []pr = new Profesor[3];
		
		for (int i = 0;i<pr.length;i++) {
			pr[i]=new Profesor((i+1),bb);
			pr[i].start();
		}
		
		for (int i = 0;i<es.length;i++) {
			es[i]=new Estudiante((i+1),bb);
			es[i].start();
		}
		
		
				

	}

}
