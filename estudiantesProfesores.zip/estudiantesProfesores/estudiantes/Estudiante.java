package estudiantes;

public class Estudiante extends Thread{
	
	private Biblioteca bb;
	private int id;
	
	public Estudiante(int id, Biblioteca bb) {
		this.id=id;
		this.bb=bb;
	}
	
	@Override
	public void run() {
		
		while (true) {
			
			bb.lee(this.id);
			//leyendo
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			bb.salLectura(this.id);
			
		}
	}

}
