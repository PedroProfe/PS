package estudiantes;

public class Profesor extends Thread{
	

	private Biblioteca bb;
	private int id;
	
	public Profesor(int id, Biblioteca bb) {
		this.id=id;
		this.bb=bb;
	}
	
	@Override
	public void run() {
		
		while (true) {
			
			bb.escribe(this.id);
			//leyendo
			
			bb.salEscritura(this.id);
			
		}
	}

}
