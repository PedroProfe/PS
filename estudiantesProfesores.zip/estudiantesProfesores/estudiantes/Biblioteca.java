package estudiantes;

public class Biblioteca {
	
	private boolean hayprofesor=false;
	private int numLectores=0;
	private int numProfesor=0;
	
	
	public synchronized void lee(int id) {
		
		while(hayprofesor || numProfesor>0) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
		numLectores++;
		System.out.println("Soy el estudiante "+id +" y estoy leyendo");		
	}
	public synchronized void salLectura(int id) {
		numLectores--;
		System.out.println(" Soy el estudiante "+ id + " y estoy dejando la biblioteca");
		if (numLectores==0) {notify();}
	}	
	public synchronized void escribe(int id) {
		this.numProfesor++;
		while (numLectores>0 || hayprofesor) {
			try {
				wait();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		hayprofesor=true;
		System.out.println("soy el profesor "+id+" y estoy escribiendo");		
	}
	
	public synchronized void salEscritura(int id) {
		this.numProfesor--;
		System.out.println("soy el profesor " + id +" y acabo de terminar de escribir");
		hayprofesor=false;		
		notifyAll();
		
	}
}
